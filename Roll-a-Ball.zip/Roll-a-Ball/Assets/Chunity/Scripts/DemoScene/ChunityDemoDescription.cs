﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChunityDemoDescription : MonoBehaviour
{
    [TextArea]
    public string description;
}
